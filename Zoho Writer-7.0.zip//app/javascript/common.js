Sprints.define("Agile.Common", function(require) {

    const connection = 'zoho_writer';
    const WRITER_URL = "https://zohoapis";
    this.err_type = "error";
    this.succ_type = "success";
    this.err_msg = "Error occurred. Please try again later.";
    this.succ_ass = "Document(s) associated successfully";
    this.succ_diss = "Attachment(s) disassociated successfully";
    this.ass_file_lmt = 10;

    this.getDomain = () => {
        const SVC_ORIGIN = App.instance.context().serviceOrigin;
        const START_INDEX=SVC_ORIGIN.indexOf('.')+1;
        return SVC_ORIGIN.substring(SVC_ORIGIN.indexOf('.',START_INDEX));
    };

    const WRITER_HOST = "https://writer.zoho" + Agile.Common.getDomain() + "/";
    const WRITER_OPEN_URL = new RegExp('^' + WRITER_HOST + "writer\/open\/([a-z0-9]{32,150})");

    this.showMessage = (type, msg) => {
        App.instance.dispatch("zs-flash-message", {
            message: msg,
            type
        });
    };

    const request = (url) => {
        return App.instance.request(url);
    };

    this.writerHost = () => {
        return WRITER_URL + Agile.Common.getDomain();
    };

    this.invokeSprintsUrl = (Url, attachment = false) => {
        if (!attachment) {
            Url["url"] = Agile.Create.getData("sprintsurl");
        }
        Url["connectionLinkName"] = connection;
        return request(Url);
    };

    this.invokeWriterUrl = (Url) => {
        Url['url'] = Agile.Common.writerHost() + Url.url;
        Url["connectionLinkName"] = connection;
        return request(Url);
    };



    this.closeModel = () => {
        App.instance.dispatch("zs-destroy");
    };

    this.getDateStrFromISO = (date, SPRINTS_DETAILS) => {
        const DATEFORMAT = SPRINTS_DETAILS.team.dateFormat + " " + SPRINTS_DETAILS.team.timeFormat;
        const TIMEZONE = SPRINTS_DETAILS.team.timeZone;
        return moment(date).tz(TIMEZONE).format(DATEFORMAT);
    };

    this.getDocID = (url) => {
        let matches = url.match(WRITER_OPEN_URL);
        return matches ? matches[1] : null;
    };

    this.getIndex = (document_id, ASS_DOC_DETS) => {
        for (var i = 0; i < ASS_DOC_DETS.length; i++) {
            if (Agile.Common.getDocID(ASS_DOC_DETS[i].open_url) === document_id) {
                return i;
            }
        }
        return -1;
    }
});