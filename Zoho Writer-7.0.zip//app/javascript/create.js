Sprints.define("Agile.Create", function(require) {

    const EMPTY_PAGE_CN1 = "You haven't created or associated any documents yet";
    const EMPTY_PAGE_CN2 = "Attach existing Zoho Writer documents to a work item or create new Writer documents here.";
    const SEARCH_PAGE_CN1 = "No Writer documents available";
    const SEARCH_PAGE_CN2 = "Search for a relevant attachment";
    const TEMPLATE_TYPE = ["Choose Template", "Blank Document"];
    const TEMPLATE_FOLDERS = ["My Template", "Org Template", "Public Template"];
    const LICEN_PAGE_CN1 = "You don't seem to have a Zoho Writer account";
    const LICEN_PAGE_CN2 = "Create your Zoho Writer account and associate it with Sprints to create and attach documents.";
    const PERMISSION_DENIED_MESSAGE = "You don't have permission to access this file. Please contact your administrator.";
    const FILE_DELETED_MESSAGE = "This file is deleted. Please contact your administrator.";
    const GENERIC_MESSAGE = "You don't have permission to access this file. Please contact your administrator.";
    const PERMISSION_DENIED_ERROR_CODE = "R5010";
    const FILE_DELETED_ERROR_CODE = "R5018";

    const setData = (key, value) => {
        $("#js-zoho_writer").data(key, value);
    };

    this.getData = (key) => {
        return $("#js-zoho_writer").data(key);
    };

    const showAlert = (Id) => {
        $(Id).addClass("wr-flderror-show");
        setTimeout(function() {
            $(Id).removeClass("wr-flderror-show");
        }, 1000);
    };

    const setTemplates = () => {
        $.templates({
            emptypage: "#js-wr-emptypage",
            doclistpage: "#js-wr-docslistpage",
            createpage: "#js-wr-formpage"
        });
    };

    const select2Folders = {
        LoadTempChoice: () => {
            $("#js-wr-select-template_type").select2({
                data: TEMPLATE_TYPE,
                placeholder: "Select template type",
                closeOnSelect: true,
            });
        },
        LoadFoldList: () => {
            $("#js-wr-select-template_folder").select2({
                data: TEMPLATE_FOLDERS,
                placeholder: "Select template folder",
                closeOnSelect: true,
            });
        },
        getPublicTemplateCategory: () => {
            const PUBLIC_TEMPLATES = Agile.Create.getData("writerpublictemplate");
            const PUBLIC_CATEGORY = [];
            for (const CATEGORY in PUBLIC_TEMPLATES) {
                const TEMP_OBJECT = {
                    id: CATEGORY,
                    text: PUBLIC_TEMPLATES[CATEGORY].entries[0].category
                };
                PUBLIC_CATEGORY.push(TEMP_OBJECT);
            }

            return PUBLIC_CATEGORY;
        },
        LoadTemplateCategory: () => {
            $("#js-wr-select-public-template_category").select2({
                data: select2Folders.getPublicTemplateCategory(),
                placeholder: "Select template category",
                closeOnSelect: true,
                templateResult: function(data) {
                    if (data.loading === true) {
                        return ($("<span>Loading...</span>"));
                    }
                    if (data.hasOwnProperty("text") && data.hasOwnProperty("id")) {
                        const OPTION = '<div class="wr-temp-txt"><span class="txt" id="wr-tmpl-name">' + agEncoder.encodeHTML(data.text) + '</span></div>';
                        return $(OPTION);
                    }
                    return;
                },
                templateSelection: function(state) {
                    if (state.id) {
                        const OPTION = "<span>" + agEncoder.encodeHTML(state.text) + "</span>";
                        return $(OPTION);
                    } else {
                        const OPTION = '<span class="fl" style="color:gray">' + agEncoder.encodeHTML(state.text) + '</span>';
                        return $(OPTION);
                    }
                }
            });
            $("#js-wr-select-public-template_category").val("sprints").trigger("change");
            $("#js-category,#js-public").removeClass("hide");
        },
        setpublicTemplList: () => {
            $("#js-wr-select-public_template").select2({
                closeOnSelect: true,
                placeholder: "Select template",
                data: Agile.Create.getData("writerpublictemplate")[$("#js-wr-select-public-template_category").val()].entries,
                templateResult: function(data) {
                    if (data.loading === true) {
                        return ($("<span>Loading...</span>"));
                    }
                    if (data.hasOwnProperty("name") && data.hasOwnProperty("thumbnail_url")) {
                        const OPTION = '<div class="wr-temp-box mb10 mt10"><div class="img-container" style="height:35px;width:35px;"><img src=' + agEncoder.encodeHTMLAttribute(data.thumbnail_url) + ' class="flw100per js-preview_image" style="height:35px;width:35px"/></div><div class="wr-temp-txt"><span class="txt" id="wr-tmpl-name">' + agEncoder.encodeHTML(data.name) + '</span></div></div>';
                        const $elem = $(OPTION);
                        $elem.find('img').one('error', function() {
                            $(this).addClass("wr_zipdoc_img").attr("src", "../images/writer.svg");
                        });
                        return $elem;
                    }
                    return;
                },
                templateSelection: function(state) {
                    if (state.id) {
                        const OPTION = "<span>" + agEncoder.encodeHTML(state.name) + "</span>";
                        return $(OPTION);
                    } else {
                        const OPTION = '<span class="fl" style="color:gray">Select Template</span>';
                        return $(OPTION);
                    }
                }
            });
        },
        setTemplList: () => {
            $("#js-wr-select-template").select2({
                closeOnSelect: true,
                placeholder: "Select template",
                ajax: {
                    data: function(params) {
                        var range = 10;
                        return {
                            offset: (params.page && params.page > 1) ? (params.page - 1) * range : 0,
                            limit: range,
                            page: params.page
                        };
                    },
                    transport: function(params, success, failure) {
                        const TEMPLATE_FOLDER = $("#js-wr-select-template_folder").val();
                        const URL_LINK = {
                            url: "/writer/api/v1/templates",
                            method: "get",
                            needLoader: false,
                            parameters: {
                                offset: params.data.offset,
                                limit: params.data.limit,
                                type: TEMPLATE_FOLDER === "My Template" ? "personal" : TEMPLATE_FOLDER === "Org Template" ? "organization" : null,
                            }
                        };
                        Agile.Common.invokeWriterUrl(URL_LINK).then(({
                            responseCode,
                            responseBody
                        }) => {
                            success(responseBody);
                        });
                    },
                    processResults: function(definitions, params) {
                        params.page = params.page || 1;
                        return {
                            results: $.map(definitions.templates, function(value, key) {
                                return {
                                    id: value.id,
                                    text: value.name,
                                    link: value.thumbnail_url,
                                    date: value.created_time
                                };
                            }),
                            pagination: {
                                more: (params.page * 10) < definitions.total_count
                            }
                        };
                    }
                },
                templateResult: function(data) {
                    if (data.loading === true) {
                        return ($("<span>Loading...</span>"));
                    }
                    const OPTION = '<div class="wr-temp-box mb10 mt10"><div class="img-container" style="height:35px;width:35px;"><img src=' + agEncoder.encodeHTMLAttribute(data.link) + ' class="flw100per js-preview_image" style="height:35px;width:35px"/></div><div class="wr-temp-txt"><span class="txt" id="wr-tmpl-name">' + agEncoder.encodeHTML(data.text) + '</span><span class="fl w100per l22 fs12 opa07">On ' + agEncoder.encodeHTML(Agile.Common.getDateStrFromISO(data.date, Agile.Create.getData("sprintsdetails"))) + '</span></div></div>';
                    const $elem = $(OPTION);
                    $elem.find('img').one('error', function() {
                        $(this).addClass("wr_zipdoc_img").attr("src", "../images/writer.svg");
                    });
                    return $elem;
                },
                templateSelection: function(state) {
                    if (state.id) {
                        const OPTION = "<span>" + agEncoder.encodeHTML(state.text) + "</span>";
                        return $(OPTION);
                    } else {
                        const OPTION = '<span class="fl">Select Template</span>';
                        return $(OPTION);
                    }

                }
            });
        },
    };
    const eventsforSelect2 = {
        eventforTemplatetype: (event) => {
            const VALUE = event.currentTarget.value;
            formPage.loadMore(VALUE);
        },
        eventforTemplateFolder: (event) => {
            $(event).find("#js-wr-select-public_template").val(null).trigger("change");
            const VALUE = event.currentTarget.value;
            if (VALUE) {
                formPage.loadTemplList(VALUE);
            }
        },
        eventforTemplateCategory: (event) => {
            const VALUE = event.currentTarget.value;
            $("#js-wr-select-public_template").val(null).trigger("change");
            if (VALUE) {
                select2Folders.setpublicTemplList();
            }
        },
        eventforTemplateChangeEvents: () => {
            const CONTAINER = $("#formContainer");
            const PUBLIC_TEMPLATE_ID = CONTAINER.find("#js-wr-select-public_template").val();
            const TEMPLATE_ID = CONTAINER.find("#js-wr-select-template").val();
            if (PUBLIC_TEMPLATE_ID || TEMPLATE_ID) {
                formPage.enableCreateBtn(2);
            } else {
                formPage.enableCreateBtn(1);
            }
        }
    };
    const formPage = {
        loadMore: (value) => {
            if (value === "Choose Template") {
                select2Folders.LoadFoldList();
                $("#js-tmpl-type").removeClass('hide');
                $("#js-wr-select-template_folder").val("Public Template").trigger("change");
            } else {
                $("#js-tmpl-type,#js-general,#js-public,#js-category").addClass("hide");

            }
        },
        hideandVisibleSelect: (category) => {
            $("#js-wr-select-public_template").val(null).trigger("change");
            $("#js-wr-select-template").val(null).trigger("change");
            if (category === "public") {
                formPage.enableCreateBtn(1);
                $("#js-general").addClass("hide");

            } else {
                $("#js-general").removeClass("hide");
                $("#js-public,#js-category").addClass("hide");
            }
        },
        loadTemplList: (value) => {
            if (value === "My Template") {
                formPage.hideandVisibleSelect("personal");
                select2Folders.setTemplList();
            } else if (value === "Org Template") {
                formPage.hideandVisibleSelect("organization");
                select2Folders.setTemplList();
            } else if (value === "Public Template") {
                formPage.hideandVisibleSelect("public");
                const PUBLIC_TMPL = Agile.Create.getData("writerpublictemplate");
                if (!PUBLIC_TMPL) {
                    const URL_LINK = {
                        url: "/writer/api/v1/public/templates",
                        method: "get"
                    };
                    Agile.Common.invokeWriterUrl(URL_LINK).then((response) => {
                        if (response.responseCode == 200) {
                            setData('writerpublictemplate', response.responseBody);
                            select2Folders.LoadTemplateCategory();
                        } else {
                            Agile.Common.showMessage(Agile.Common.err_type, Agile.Common.err_msg);
                        }
                    });

                } else {
                    select2Folders.LoadTemplateCategory();
                }

            }

        },
        formpageCreateEvent: (event) => {
            const CONTAINER = $("#formContainer");
            const FILE_NAME = CONTAINER.find("#js-wr-doc-title").val().trim();
            const TEMPLATE_OPTION = CONTAINER.find("#js-wr-select-template_type").val();
            if (!FILE_NAME) {
                showAlert("#js-title");
            } else {
                if (!TEMPLATE_OPTION) {
                    showAlert("#js-type");
                } else if (TEMPLATE_OPTION === "Choose Template") {
                    const TEMPLATE_FOLDER = CONTAINER.find("#js-wr-select-template_folder").val();
                    const TEMPLATE_CATEGORY = CONTAINER.find("#js-wr-select-public-template_category").val();
                    if (!TEMPLATE_FOLDER) {
                        showAlert("#js-folder");
                    } else {
                        let Template_Id = "";
                        if (TEMPLATE_FOLDER === "Public Template") {
                            if (!TEMPLATE_CATEGORY) {
                                showAlert(".js-cat");
                            } else {
                                Template_Id = CONTAINER.find("#js-wr-select-public_template").val();
                            }
                        } else {
                            Template_Id = CONTAINER.find("#js-wr-select-template").val();
                        }

                        if (!Template_Id) {
                            showAlert(".js-tmpl");
                        } else {
                            formPage.createNewfile(FILE_NAME, Template_Id);
                        }
                    }

                } else {
                    formPage.createNewfile(FILE_NAME);
                }
            }
        },
        formpageCancelEvent: (event) => {
            frontpage("cancel");
        },
        createNewfile: (file_name, template_id) => {
            let param = {
                filename: file_name
            };
            if (template_id) {
                param.template_id = template_id;
            }

            Agile.Common.invokeWriterUrl({
                url: "/writer/api/v1/documents",
                method: "post",
                parameters: param
            }).then((response) => {
                if (response.responseCode == 200) {
                    const WRITER_URL = Agile.Common.writerHost() + "/writer/open/" + response.responseBody.document_id;
                    var anchor = document.createElement("a");
                    Object.assign(anchor, {
                        type: "hidden",
                        target: "_blank",
                        rel: "noopener,noreferrer",
                        id: "js-newdocument",
                        href: WRITER_URL
                    });
                    $("#js-title").append(anchor);
                    const ANCHOR = $("#js-newdocument");
                    ANCHOR[0].click();
                    ANCHOR.remove();
                    associateDocs([response]);
                } else {
                    Agile.Common.showMessage(Agile.Common.err_type, Agile.Common.err_msg);
                }
            });
        },
        enableCreateBtn: (FOCUS_COUNT) => {
            $("#formContainer").find("#js__crtBtn").attr("disabled", FOCUS_COUNT != 2);
        },
        eventforONError: (event) => {
            event.target.src = "../images/writer.svg";
            event.target.classList.add('wr_zipdoc_img');
        },
    };

    const eventsforHomePage = {
        eventforCreateBtn: (event) => {
            $("#js-zoho_writer").html($.render.createpage({}));
            select2Folders.LoadTempChoice();
            $("#js__crtBtn").attr("disabled", true);
            $("#js-wr-doc-title").focus();
            $("#js-wr-select-template_type").val("Blank Document").trigger("change");
            formPage.enableCreateBtn(2);
        },
        eventforAssBtn: (event) => {
            const styles = {
                width: "900px",
                height: "520px"
            };
            let assoacited_document_details = [];
            const ASOCIATED_DOCUMENTS = Agile.Create.getData("associateddocument");
            if (ASOCIATED_DOCUMENTS.responseCode == 200 && ASOCIATED_DOCUMENTS.responseBody.hasOwnProperty("data")) {
                assoacited_document_details = ASOCIATED_DOCUMENTS.responseBody.data.attachments;
            }
            App.instance.modal({
                url: "/app/html/associate.html",
                parentWidgetId: ZSDK._getRootInstance().key,
                styles,
                hideCloseBtn: true
            }).then(function(widget) {
                let widgetApp = App.instance.getWidget(widget.widgetID);
                widgetApp.on("model.open", function() {
                    widgetApp.emit("model.view", assoacited_document_details);
                });
                widgetApp.on("model.close", function(assoacited_document_details) {
                    associateDocs(assoacited_document_details);
                });
            });
        },
        eventforDisAss: (event) => {
            DisassociateFolder.dissAssociatefromDb(event.currentTarget.parentElement.parentElement.children[1].id);
        },
        eventforPreview: (event) => {
            const DOCUMENT_ID = event.currentTarget.id;
            let writer_document_obj = null;
            const ASS_DOC_DETS = Agile.Create.getData("associateddocumentdetails");
            const DOCUMENT_INDEX = Agile.Common.getIndex(DOCUMENT_ID, Agile.Create.getData("associateddocument").responseBody.data.attachments);
            writer_document_obj = ASS_DOC_DETS[DOCUMENT_INDEX].responseBody;
            if (writer_document_obj) {
                previewPage(writer_document_obj);
            }
        },
        visibleSearch: () => {
            $("#js-myInput").val('');
            $("#js__search_rslt").css("top", "0px");
            $("#js-myInput").focus();
        },
        hideSearch: () => {
            $("#js__search_rslt").css("top", "-40px");
            setTimeout(function() {
                $("#js-zoho_writer").empty();
                const ASS_DOC_DETS = Agile.Create.getData("associateddocumentdetails");
                docsListPage(ASS_DOC_DETS);
            }, 200);

        },
        searchBy: (event) => {
            let value = event.currentTarget.value;
            const KEY = event.which;
            if (event.type === "paste") {
                const CLIPB_DATA = event.clipboardData || event.originalEvent.clipboardData || window.clipboardData;
                value = CLIPB_DATA.getData("text").trim();
            }
            if (value.length > 0) {
                value = value.toLowerCase().trim();
                const ASOCIATED_FILES = $("#js-docslist").children();
                let matching_count = 0;
                $.map(ASOCIATED_FILES, function(object, key) {
                    const FILE_NAME = object.children[0].children[1].innerHTML.toLowerCase();
                    if (!(FILE_NAME.indexOf(value) > -1)) {
                        object.classList.add("hide");
                    } else {
                        object.classList.remove("hide");
                        matching_count = +1;
                    }
                });
                if (matching_count === 0) {
                    $("#js-empty-search").removeClass("hide");
                    $("#js-buttons").addClass("hide");
                } else {
                    $("#js-empty-search").addClass("hide");
                    $("#js-buttons").removeClass("hide");
                }

            } else if (KEY === 8 && value.length <= 0) {
                $("#js-empty-search").addClass("hide");
                const ASSOCIATED_DOCUMENTS = $("#js-docslist").children();
                $.map(ASSOCIATED_DOCUMENTS, function(object, key) {
                    object.classList.remove("hide");
                });
                $("#js-buttons").removeClass("hide");
            }
        },
    };

    const DisassociateFolder = {
        dissAssociatefromDb: (document_id) => {

            const ASSOCIATED_DOCUMENTS = Agile.Create.getData("associateddocument");

            let eTag = '';

            if (ASSOCIATED_DOCUMENTS.responseHeaders.etag) {
                eTag = ASSOCIATED_DOCUMENTS.responseHeaders.etag;
            }
            let badge_count = "0";

            if (ASSOCIATED_DOCUMENTS.responseBody.hasOwnProperty("data") && ASSOCIATED_DOCUMENTS.responseBody.data.hasOwnProperty("attachments")) {
                badge_count = (ASSOCIATED_DOCUMENTS.responseBody.data.attachments.length - 1).toString();
            }

            const LIST_INDEX = Agile.Common.getIndex(document_id, ASSOCIATED_DOCUMENTS.responseBody.data.attachments);
            const ASS_DOC_DETS = Agile.Create.getData("associateddocumentdetails");

            let url_link = '';

            const HEADERS = {
                "If-match": eTag,
                "X-BADGE-COUNT": badge_count
            };

            if (badge_count > "0") {
                const PAYLOAD = JSON.stringify([{
                    "op": "remove",
                    "path": `/attachments/${LIST_INDEX}`
                }]);
                url_link = {
                    method: "patch",
                    headers: HEADERS,
                    payload: PAYLOAD
                };
            } else {
                url_link = {
                    method: "delete",
                    headers: HEADERS
                };
            }
            App.instance.dispatch("zs-confirm-message", {
                message: "Are you sure you want to disassociate this attachment?"
            }).then((response) => DisassociateFolder.deleteDocument(response, url_link, ASS_DOC_DETS, LIST_INDEX));

        },
        deleteDocument: (response, url_link, values, doc_ind) => {
            if (response === true) {
                Agile.Common.invokeSprintsUrl(url_link).then((response) => {
                    if (response.responseCode == 200) {
                        directToTemplatesPages(response, values, doc_ind);
                    } else {
                        Agile.Common.showMessage(Agile.Common.err_type, Agile.Common.err_msg);
                    }
                });
            }
        },
    };

    const getSelectedFiles = (previousresponse, eTag) => {
        let associated_files = [];
        $.map(previousresponse, function(value, key) {
            let temp_obj = {
                open_url: value.responseBody.open_url
            };
            if (!eTag) {
                associated_files.push(temp_obj);
            } else {
                const OBJ = {
                    "op": "add",
                    "path": "/attachments/-",
                    "value": temp_obj
                };
                associated_files.push(OBJ);
            }
        });
        if (!eTag) {
            return JSON.stringify({
                attachments: associated_files
            });
        }
        return JSON.stringify(associated_files);
    };

    const associateDocs = (previousresponse) => {

        const ASSOCIATED_DOCUMENTS = Agile.Create.getData("associateddocument");

        let eTag = "";
        let badge_count = previousresponse.length.toString();

        if (ASSOCIATED_DOCUMENTS.responseCode === 200 && ASSOCIATED_DOCUMENTS.responseBody.hasOwnProperty("data") && ASSOCIATED_DOCUMENTS.responseBody.data.hasOwnProperty("attachments")) {
            badge_count = (ASSOCIATED_DOCUMENTS.responseBody.data.attachments.length + parseInt(badge_count)).toString();
        }
        if (ASSOCIATED_DOCUMENTS.responseHeaders.etag) {
            eTag = ASSOCIATED_DOCUMENTS.responseHeaders.etag;
        }

        const HEADER = {
            "X-BADGE-COUNT": badge_count,
            "If-Match": eTag
        };
        let url_method = eTag ? "patch" : "put";
        let pay_load = getSelectedFiles(previousresponse, eTag);

        const URL_LINK = {
            method: url_method,
            headers: HEADER,
            payload: pay_load
        };

        Agile.Common.invokeSprintsUrl(URL_LINK).then((response) => {
            if (response.responseCode == 200) {
                frontpage(response, previousresponse);
            } else {
                Agile.Common.showMessage(Agile.Common.err_type, Agile.Common.err_msg);
            }
        });
    };

    const previewPage = (wr_obj) => {
        const styles = {
            width: "98.5%",
            height: "95.5%"
        };
        App.instance.modal({
            url: "/app/html/preview.html",
            parentWidgetId: ZSDK._getRootInstance().key,
            styles,
            hideCloseBtn: true
        }).then(function(widget) {
            let widgetApp = App.instance.getWidget(widget.widgetID);
            widgetApp.on("model.open", function() {
                widgetApp.emit("model.view", wr_obj);
            });
        });
    };

    const setPermissions = (No_Of_Documents) => {
        $(".js__crt,.js__ass").prop("disabled", No_Of_Documents >= Agile.Common.ass_file_lmt);
    };

    const messageHelper = (errorCode) => {
        if (errorCode === PERMISSION_DENIED_ERROR_CODE) {
            return PERMISSION_DENIED_MESSAGE;
        } else if (errorCode === FILE_DELETED_ERROR_CODE) {
            return FILE_DELETED_MESSAGE;
        }
        return GENERIC_MESSAGE;
    };

    const setfilePermissions = (values) => {
        const ASS_FILES = Agile.Create.getData("associateddocument").responseBody.data.attachments;
        for (var i = 0; i < values.length; i++) {
            const OPEN_URL = ASS_FILES[i].open_url;
            const FILE = values[i];
            if (FILE.responseCode === 200) {
                FILE.responseBody.open_url = OPEN_URL;
            } else {
                FILE.responseBody["open_url"] = OPEN_URL;
                FILE.responseBody["document_id"] = Agile.Common.getDocID(OPEN_URL);
                FILE.responseBody["message"] = messageHelper(FILE.responseBody.error.errorcode);
            }
        }
        return values;
    };

    const emptyPage = () => {
        const DATA = {
            content1: EMPTY_PAGE_CN1,
            content2: EMPTY_PAGE_CN2,
            url: "../images/empty-attachments.svg",
            buttons: true,
            "class": "h100per"
        };
        $("#js-zoho_writer").html($.render.emptypage(DATA));
        setPermissions(0);
        setData('associatedfilecount', 0);
    };

    const docsListPage = (documents) => {
        setData('associatedfilecount', documents.length);
        documents = setfilePermissions(documents);
        setData('associateddocumentdetails', documents);
        const HTML = $.render.doclistpage({
            array: documents,
            Sprints_context: Agile.Create.getData("sprintsdetails")
        }, {
            changeDateFormat: Agile.Common.getDateStrFromISO
        });
        $("#js-zoho_writer").html(HTML);
        const SEARCH_PAGE_DATA = {
            content1: SEARCH_PAGE_CN1,
            content2: SEARCH_PAGE_CN2,
            url: "../images/empty-search.svg",
            buttons: false,
            "class": "h90per hide",
            id: "js-empty-search"
        };
        $("#js-doclist-container").append($.render.emptypage(SEARCH_PAGE_DATA));
        setPermissions(documents.length);
    };

    const frontpage = (response, previousresponse) => {
        let values = Agile.Create.getData("associateddocumentdetails");
        if (response === "cancel") {
            if (values.length > 0) {
                docsListPage(values);
            } else {
                emptyPage();
            }
            return;
        }

        setData("associateddocument", response);
        if (response && response.responseCode == 200) {
            Agile.Common.showMessage(Agile.Common.succ_type, Agile.Common.succ_ass);
        } else {
            Agile.Common.showMessage(Agile.Common.err_type, Agile.Common.err_msg);
        }

        if (previousresponse) {
            if (Array.isArray(previousresponse)) {
                values = values.concat(previousresponse);
            } else {
                values.push(previousresponse);
            }
        }

        if (values.length > 0) {
            docsListPage(values);
        } else {
            emptyPage();
        }
    };

    const directToTemplatesPages = (response, values, doc_ind) => {

        if (response.responseCode === 200) {
            Agile.Common.showMessage(Agile.Common.succ_type, Agile.Common.succ_diss);
            values.splice(doc_ind, 1);
            setData("associateddocument", response);
        } else {
            Agile.Common.showMessage(Agile.Common.err_type, Agile.Common.err_msg);
        }

        if (values.length > 0) {
            docsListPage(values);
        } else {
            emptyPage();
        }

    };

    const getDocumentDetails = (attachments) => {

        const TEMP_URL = "/writer/api/v1/documents/";
        let resObj = [];

        for (var attachment of attachments) {

            resObj.push(Agile.Common.invokeWriterUrl({
                url: TEMP_URL + Agile.Common.getDocID(attachment.open_url),
                method: "get",
            }));
        }

        return Promise.all(resObj);
    };

    const getAssociatedDocuments = () => {
        const URL_LINK = {
            method: "get",
        };

        Agile.Common.invokeSprintsUrl(URL_LINK).then((response) => {
            if (response.responseCode === 200) {
                setData("associateddocument", response);
                getDocumentDetails(response.responseBody.data.attachments).then((values) => docsListPage(values));
            } else if (response.responseCode === 404) {
                setData("associateddocument", response);
                emptyPage();
            } else {
                Agile.Common.showMessage(Agile.Common.err_type, Agile.Common.err_msg);
            }
        });

    };

    const bindEvents = () => {
        $("#js-zoho_writer").on("click", ".js__crt", eventsforHomePage.eventforCreateBtn)
            .on("click", ".js__ass", eventsforHomePage.eventforAssBtn)
            .on("click", ".js-dissassociate", eventsforHomePage.eventforDisAss)
            .on("click", ".js-wr-lstttl", eventsforHomePage.eventforPreview)
            .on("click", ".js__search", eventsforHomePage.visibleSearch)
            .on("click", ".js__closeSerach", eventsforHomePage.hideSearch)
            .on("click", "#js__crtBtn", formPage.formpageCreateEvent)
            .on("click", ".js__cnclBtn", formPage.formpageCancelEvent)
            .on("keyup", "#js-myInput", eventsforHomePage.searchBy)
            .on("paste", "#js-myInput", eventsforHomePage.searchBy)
            .on("change", "#js-wr-select-template_type", eventsforSelect2.eventforTemplatetype)
            .on("change", "#js-wr-select-template_folder", eventsforSelect2.eventforTemplateFolder)
            .on("change", "#js-wr-select-public-template_category", eventsforSelect2.eventforTemplateCategory)
            .on("change", "#js-wr-select-template", eventsforSelect2.eventforTemplateChangeEvents)
            .on("change", "#js-wr-select-public_template", eventsforSelect2.eventforTemplateChangeEvents);

    };

    const init = () => {
        setData('associateddocumentdetails', []);
        bindEvents();
        getAssociatedDocuments();
    };

    const licenseValidation = (status) => {
        setTemplates();
        const USER_INFO = status.responseBody.user_info;
        if (USER_INFO.is_dms_available) {
            App.instance.dispatch("zs-context").then((response) => {
                setData("sprintsdetails", response);
                let url = "";
                if (response.hasOwnProperty("item")) {
                    url = `/zsapi/team/${response.team.id}/projects/${response.project.id}/item/${response.item.id}/extensions/${response.extension.id}/data`;
                } else if (response.hasOwnProperty("meeting")) {
                    url = `/zsapi/team/${response.team.id}/projects/${response.project.id}/meeting/${response.meeting.id}/extensions/${response.extension.id}/data`;
                } else if (response.hasOwnProperty("sprint")) {
                    url = `/zsapi/team/${response.team.id}/projects/${response.project.id}/sprints/${response.sprint.id}/extensions/${response.extension.id}/data`;
                } else if (response.hasOwnProperty("release")) {
                    url = `/zsapi/team/${response.team.id}/projects/${response.project.id}/release/${response.release.id}/extensions/${response.extension.id}/data`;
                }
                setData('sprintsurl', url);
                init();
            });
        } else {
            const HTML = $.render.emptypage({
                url: "../images/writer_not_linked_empty_page.svg",
                content1: LICEN_PAGE_CN1,
                content2: LICEN_PAGE_CN2,
                onboard_url: USER_INFO.onboard_url,
                buttons: true,
                "class": "h100per"
            });
            $("#js-zoho_writer").html(HTML);
        }
    };

    Object.defineProperties(this, {
        writerExtension: {
            value: () => Agile.Common.invokeWriterUrl({
                url: "/writer/api/v1/me?from=zohoforms",
                method: "get"
            }).then((response) => {
                licenseValidation(response);
            })
        }
    });
});