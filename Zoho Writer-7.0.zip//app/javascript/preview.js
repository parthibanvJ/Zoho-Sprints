Sprints.define("Agile.preview", function(require) {

    const ATTACHMENT_SUCCESS_MESSAGE = "Document attached successfully";
    const DOC_FORMAT = ["docx", "odt", "rtf", "txt", "html", "pdf"];

    const setData = (key, value) => {
        $("#js-wr-doc-preview").data(key, value);
    };

    const getData = (key) => {
        return $("#js-wr-doc-preview").data(key);
    };

    const setTemplates = () => {
        $.templates({
            previewPage: "#js-wr-preview"
        });
    };

    const hidepopups = () => {
        $("#js-wr_attach,#js-wr_export").removeClass("wr_pop_morepop_selected");
        $("#js-wr_openpop").removeClass("wr-detTopMore--sel");
        $("#js-more-action-pop,#js-wr__attch-pop,#js-wr__exp-pop").addClass("hide");
        $("#js-wr-detSepBdr").removeClass("hide");
    };

    const eventforClosepop = (event) => {
        if (!event.target.className.includes("js_attach") && !event.target.className.includes("js_export")) {
            hidepopups();
        } else if (event.target.className.includes("js_export-opt") || event.target.className.includes("js_attach-opt")) {
            hidepopups();
        }
    };

    const eventforOpenExportpop = (event) => {
        event.currentTarget.classList.add("wr_pop_morepop_selected");
        if (event.currentTarget.nextElementSibling) {
            event.currentTarget.nextElementSibling.classList.remove("wr_pop_morepop_selected");
        }
        $("#js-wr__exp-pop").removeClass("hide");
        $("#js-wr__attch-pop").addClass("hide");
    };

    const eventforOpenpop = (event) => {
        event.stopPropagation();
        event.currentTarget.classList.add("wr-detTopMore--sel");
        $("#js-more-action-pop").removeClass("hide");
        $("#js-wr-detSepBdr").addClass("hide");
    };

    const addAttachment = (sprints_details, wr_document_format) => {
        const PREVIEW_DOCUMENT = getData("previewdocument");
        const PAYLOAD = JSON.stringify({
            team_id: sprints_details.team.id,
            project_id: sprints_details.project.id,
            sprint_id: sprints_details.sprint.id,
            item_id: sprints_details.item.id,
            document_id: PREVIEW_DOCUMENT.document_id,
            document_format: wr_document_format,
            document_name: PREVIEW_DOCUMENT.document_name,
        });
        const TEMP_URL = `/zsapi/team/${sprints_details.team.id}/extensions/${sprints_details.extension.id}/functions?functionUuid={{parameters.add_attachment_function_uuid}}&version={{parameters.add_attachment_function_version}}&isDetailedResponse=true`;
        const URL_LINK = {
            url: TEMP_URL,
            method: "post",
            payload: PAYLOAD,
            isDetailedResponse: true
        };
        Agile.Common.invokeSprintsUrl(URL_LINK, true).then((response) => {
            if (response.responseCode === 200 && response.responseBody.response.code == 200) {
                Agile.Common.showMessage(Agile.Common.succ_type, ATTACHMENT_SUCCESS_MESSAGE);
            } else {
                Agile.Common.showMessage(Agile.Common.err_type, Agile.Common.err_msg);
            }
        });
    };

    const eventforAttachment = (event) => {
        eventforClosepop(event);
        const FORMAT = event.currentTarget.id;
        const SPRINTS_DETAILS = getData("sprintsdetails");
        addAttachment(SPRINTS_DETAILS, FORMAT);
    };
    const eventforOpenAttachmentpop = (event) => {
        event.currentTarget.classList.add("wr_pop_morepop_selected");
        event.currentTarget.previousElementSibling.classList.remove("wr_pop_morepop_selected");
        $("#js-wr__attch-pop ").removeClass("hide");
        $("#js-wr__exp-pop").addClass("hide");
    };

    const bindEvents = () => {
        $("#js-wr-doc-preview").on("click", ".js_openpop", eventforOpenpop)
            .on("click", ".js_export", eventforOpenExportpop)
            .on("click", ".js_wrt-detpar", eventforClosepop)
            .on("click", ".js_attach", eventforOpenAttachmentpop)
            .on("click", ".js_attach-opt", eventforAttachment)
            .on("click", ".js_close", Agile.Common.closeModel);

        $('body').on('keyup', (event) => {
            if (event.keyCode === 27) {
                Agile.Common.closeModel();
            }
        });
    };

    const checkPermission = () => {
        const SPRINTS_DETAILS = getData("sprintsdetails");
        if (!SPRINTS_DETAILS.hasOwnProperty("item") || !SPRINTS_DETAILS.item.hasEditPermission) {
            $("#js-wr_attach").remove();
        }
    };

    const inserttemplate = (preview_document) => {
        preview_document['document_formats'] = DOC_FORMAT;
        preview_document['Sprints_context'] = getData("sprintsdetails");
        $("#js-wr-doc-preview").html($.render.previewPage(preview_document, {
            changeDateFormat: Agile.Common.getDateStrFromISO
        }));
        bindEvents();
        checkPermission();
    };

    const init = (sprints_details) => {
        setTemplates();
        setData("sprintsdetails", sprints_details);
        App.instance.trigger("model.open");
        App.instance.on("model.view", function(preview_document) {
            setData("previewdocument", preview_document);
            inserttemplate(preview_document);
        });
    };

    Object.defineProperties(this, {
        writerpreView: {
            value: () => {
                App.instance.dispatch("zs-context").then((response) => {
                    init(response);
                });
            }
        }
    });
});