Sprints.define("Agile.associate", function(require) {

    const FILE_REQ_LMT = 50;
    const FILE_LMT = "You can associate only up to " + Agile.Common.ass_file_lmt + " files";
    const FOLDERS = ["My Documents", "Recents", "Shared with me", "Favorites"];

    const setData = (key, value) => {
        $("#associateContainer").data(key, value);
    };

    const getData = (key) => {
        return $("#associateContainer").data(key);
    };

    const setTemplates = () => {
        $.templates({
            emptyPage: "#wr-empty-page",
            docslistPage: "#wr-docslist-page"

        });
    };

    const getFiles = (url) => {
        setData("avoidcontinuouscalls", {
            search: false,
            scroll: false
        });
        return Agile.Common.invokeWriterUrl(url)
    };

    const eventBindingforDropdown = (selected_folder) => {
        initValues(false);
        document.getElementById("js-searchInput").value = '';
        document.getElementById("js-associatewithUrl").value = '';
        events.eventforVisibleSearch();
        getwriterDocs(selected_folder);
    };

    const homePage = () => {
        const FOLDER_TITLE = $("#js-dropdown-title")[0].innerHTML;
        initValues(false);
        getwriterDocs(FOLDER_TITLE);
    };
    const markAlreadyAssociatedFiles = () => {
        const ASSOCIATED_DOCUMENTS = getData("associateddocument");
        const WRITER_FILES = $("#associateContainer").children();
        if (ASSOCIATED_DOCUMENTS.length > 0) {
            $.map(WRITER_FILES, function(file, key) {
                const DOCUMENT_INDEX = Agile.Common.getIndex(file.dataset.id, ASSOCIATED_DOCUMENTS);
                if (DOCUMENT_INDEX >= 0) {
                    if (file.lastElementChild.classList.contains("js_wr_zipdoc")) {
                        file.lastElementChild.classList.remove("js_wr_zipdoc");
                        file.lastElementChild.id = "";
                    }
                    if (!file.lastElementChild.classList.contains("wr_zipdoc_added")) {
                        file.lastElementChild.classList.add("wr_zipdoc_added");
                        file.lastElementChild.children[0].classList.add("left_tooltip");
                        file.lastElementChild.children[0].classList.add("tooltip_down");
                        file.lastElementChild.children[0].setAttribute("agtitle", "Already Attached");
                    }
                }
            });
        }
    };

    const getSelectedFiles = () => {
        const WRITER_FILES = $("#associateContainer").children();
        let selected_files = [];
        $.map(WRITER_FILES, function(value, key) {
            if (value.className.includes("selected_document")) {
                const DOCUMENT_OBJ = {
                    responseBody: {
                        document_id: value.dataset.id,
                        document_name: value.dataset.name,
                        creator_id: value.dataset.createdby,
                        created_by: value.dataset.createdbyname,
                        preview_url: value.dataset.preview_url,
                        open_url: value.dataset.open_url,
                        modified_time: value.dataset.modified_time,
                        lastmodified_by: [{
                            display_name: value.dataset.last_openedby
                        }],
                        download_url: value.dataset.download_url
                    },
                    responseCode: 200
                };
                selected_files.push(DOCUMENT_OBJ);
            }
        });
        return selected_files;
    };

    const searchEmpty = (line1_content, line2_content) => {
        const CONTAINER = $("#associateContainer");
        CONTAINER.empty();
        const HTML = $.render.emptyPage({
            url: "../images/empty-search.svg",
            content1: line1_content,
            content2: line2_content
        });
        CONTAINER.append(HTML);
        $("#js-Buttons").addClass("hide");

    };
    const getSearch = () => {
        const OBJ = getData("selectedfolder");
        if (OBJ.hasOwnProperty("Search") && OBJ.Search.search) {
            return true;
        }
        return false;
    };

    const insertintoTemplate = (response) => {
        $("#js-Buttons").removeClass("hide");;
        const CONTAINER = $("#associateContainer");
        CONTAINER.empty();
        const HTML = $.render.docslistPage({
            array: response.responseBody
        });
        CONTAINER.append(HTML);
        markAlreadyAssociatedFiles();
        OnerrorEvent();

    };

    const templateSelector = (response) => {
        setData("previouscallresponse", response);
        const CONTAINER = $("#associateContainer");
        if (response.responseBody.documents.length === 0 && !getSearch()) {
            CONTAINER.empty();
            const HTML = $.render.emptyPage({
                url: "../images/empty-attachments.svg",
                content1: "No documents available",
                content2: "Please select another folder."
            });
            CONTAINER.append(HTML);
            $("#js-Buttons").addClass("hide");
            setData("avoidcontinuouscalls", {
                scroll: true,
                search: true
            });

        } else if (response.responseBody.documents.length === 0 && getSearch()) {
            setData("avoidcontinuouscalls", {
                scroll: true,
                search: true
            });
            searchEmpty("No matching documents", "Please enter a valid search criteria.");
        } else if (response.responseBody.documents.length > 0) {
            $("#js-Buttons").removeClass("hide");;
            const HTML = $.render.docslistPage({
                array: response.responseBody.documents
            });
            $("#associateContainer").append(HTML);
            markAlreadyAssociatedFiles();
            OnerrorEvent();
            setData("avoidcontinuouscalls", {
                scroll: true,
                search: true
            });
        }
    };



    const getrequest = (fold_category, fold_type, fold_search, offset) => {
        let writer_url = "/writer/api/v1/documents";
        let url_link = '';
        if (fold_category) {
            const PARAM = {
                category: fold_category,
                sortby: "modified_time",
                sort_order_by: "descending",
                offset: offset,
                limit: FILE_REQ_LMT
            };
            url_link = {
                url: writer_url,
                method: "get",
                parameters: PARAM
            };
        } else if (fold_type) {
            writer_url = writer_url + "/" + fold_type;
            const PARAM = {
                offset: offset,
                limit: FILE_REQ_LMT
            };
            url_link = {
                url: writer_url,
                method: "get",
                parameters: PARAM
            };
        } else if (fold_search) {
            if (fold_search.search) {
                writer_url = writer_url + "/search";
                const PARAM = {
                    query: fold_search.q,
                    offset: offset,
                    limit: FILE_REQ_LMT
                };
                url_link = {
                    url: writer_url,
                    method: "get",
                    parameters: PARAM
                };
            }
        }
        if (url_link) {
            if (url_link.parameters.offset === 0) {
                setData("selectedCount", 0);
            }
            getFiles(url_link).then((response) => {
                if (response.responseCode === 200) {
                    templateSelector(response);
                } else {
                    Agile.Common.showMessage(Agile.Common.err_type, Agile.Common.err_msg);
                }
            });
        }
    };


    const checkSelectedCount = (SELECTED_COUNT) => {
        const ASSOCIATED_DOC_COUNT = getData("associateddocument").length;
        if ((ASSOCIATED_DOC_COUNT + SELECTED_COUNT) >= Agile.Common.ass_file_lmt) {
            return false;
        }
        return true;
    };

    const checkboxevent = () => {
        $(document).on("click", "#js_wr_zipdoc", function() {
            let selected_Count = getData("selectedCount");
            if ($(this).find(".js__checkmark").hasClass("agicon-checkbox-checked") && !$(this).find(".js__wr_zipdoc").hasClass("wr_zipdoc_added")) {
                $(this).parent().removeClass("selected_document");
                $(this).find(".js_checkBox").removeClass("chkbox_selected");
                $(this).find(".js__checkmark").removeClass("agicon-checkbox-checked colff815f").addClass("agicon-checkbox-unchecked");
                selected_Count -= 1;

            } else {
                if (checkSelectedCount(selected_Count)) {
                    $(this).parent().addClass("selected_document");
                    $(this).find(".js_checkBox").addClass("chkbox_selected");
                    $(this).find(".js__checkmark").addClass("agicon-checkbox-checked colff815f").removeClass("agicon-checkbox-unchecked");
                    selected_Count += 1;
                } else {
                    Agile.Common.showMessage(Agile.Common.err_type, FILE_LMT);
                }
            }
            setData("selectedCount", selected_Count);
            attachbtnevent(selected_Count);
        });
    };
    const checkAssociatewithURL = (selected_files) => {
        const ASSOCIATE_WITH_URL = $("#js-associatewithUrl")[0].value;
        if (selected_files.length == 1 && ASSOCIATE_WITH_URL) {
            selected_files[0].responseBody.open_url = ASSOCIATE_WITH_URL;
        }
        return selected_files;
    };

    const attachbtnevent = (selected_count) => {
        $("#js__AttachFiles").prop("disabled", selected_count === 0);
    };

    const getAssociated_Document_Details = () => {
        App.instance.trigger("model.open");
        App.instance.on("model.view", function(doclist) {
            setData("associateddocument", doclist);
        });
    };

    const getwriterDocs = (fold_type) => {

        attachbtnevent(0);

        if (fold_type === "My Documents") {
            $("#associateContainer").empty();
            setData("selectedfolder", {
                category: "all",
                type: null
            });
            getrequest("all", null, null, 0);
        } else if (fold_type === "Recents") {
            $("#associateContainer").empty();
            setData("selectedfolder", {
                category: null,
                type: "recent"
            });
            getrequest(null, "recent", null, 0);
        } else if (fold_type === "Shared with me") {
            $("#associateContainer").empty();
            setData("selectedfolder", {
                category: "shared_to_me",
                type: null
            });
            getrequest("shared_to_me", null, null, 0);
        } else if (fold_type === "Favorites") {
            $("#associateContainer").empty();
            setData("selectedfolder", {
                category: "favourite",
                type: null
            });
            getrequest("favourite", null, null, 0);
        }
    };
    const OnerrorEvent = () => {
        $('img').on('error', function() {
            $(this).addClass("wr_zipdoc_img").attr("src", "../images/writer.svg");
        });
    };


    const addClassforselectedFolder = (title) => {
        const CONTAINER = $("#js-dropdown-title");
        const PREVIOUS_SELECTION_INDEX = FOLDERS.indexOf(CONTAINER[0].innerHTML);
        const CURRENT_SELECTION_INDEX = FOLDERS.indexOf(title);
        const FOLDERS_LIST = $("#js-dropdown-ulist").children();
        if (PREVIOUS_SELECTION_INDEX != CURRENT_SELECTION_INDEX) {
            FOLDERS_LIST[CURRENT_SELECTION_INDEX].classList.add("ag_selected");
            FOLDERS_LIST[PREVIOUS_SELECTION_INDEX].classList.remove("ag_selected");
            CONTAINER.text(title);
        }
    };

    const events = {
        eventforAssociatebtn: () => {
            let files = getSelectedFiles();
            files = checkAssociatewithURL(files);
            if (files.length > 0) {
                App.instance.trigger("model.close", files);
                Agile.Common.closeModel();
            }
        },
        eventforDropdown: () => {
            $("#js-dropdown-list").removeClass("hide");
        },
        eventForSelection: (event) => {
            const FOLDER = event.currentTarget.title;
            addClassforselectedFolder(FOLDER);
            eventBindingforDropdown(FOLDER);
        },
        evetforAssociateUrl: () => {
            $("#js-Search").attr("agtitle", "Search");
            $("#js__attachUrlOptLnk,#js-clear,#js-searchInput").addClass("hide");
            $("#js-Search").addClass("w33").removeClass("w200");
            $("#js__attachUrlOptCnt").css("right", "120px");

            setTimeout(function() {
                $("#js__attachUrlOptCnt").removeClass("opa00").addClass("opa100");
                document.getElementById("js-associatewithUrl").value = "";
                $("#js-associatewithUrl").focus();
            }, 350);

        },
        eventforVisibleSearch: () => {
            $("#js__attachUrlOptCnt").addClass("opa00").removeClass("opa100");
            $("#js-Search").removeAttr("agtitle", "Search");
            setTimeout(function() {
                $("#js__attachUrlOptCnt").css("right", "370px");
                $("#js__attachUrlOptLnk,#js-clear,#js-searchInput").removeClass("hide");
                $("#js-Search").addClass("w200").removeClass("w33");
                document.getElementById("js-searchInput").value = "";
                $("#js-searchInput").focus();
                if (getData("issearch")) {
                    homePage();
                }
            }, 350);
        },
        eventforSearch: (event) => {
            const KEY = event.which;
            if (KEY != 8 && KEY != 32 && KEY != 13) {
                setData("searchkeyentered", true);
            }
            if (KEY === 13 && getData("avoidcontinuouscalls").search) {
                initValues(false);
                setData("avoidcontinuouscalls", {
                    scroll: true,
                    search: false
                });
                const QUERY = event.target.value.toLowerCase().trim();
                if (QUERY.length > 0) {
                    $("#associateContainer").empty();
                    setData("issearch", true);
                    setData("selectedfolder", {
                        category: null,
                        type: null,
                        Search: {
                            search: true,
                            q: QUERY
                        }
                    });
                    getrequest(null, null, {
                        search: true,
                        q: QUERY
                    }, 0);
                    attachbtnevent(0);
                    setData("searchkeyentered", true);
                }
            } else if (KEY === 8) {
                const QUERY = event.target.value.trim();
                if (QUERY.length <= 1 && getData("searchkeyentered")) {
                    homePage();
                }
            }
        },

        scrollDown: () => {
            $("#associateContainer").on("scroll", function(event) {
                if ((event.currentTarget.offsetHeight + event.currentTarget.scrollTop) > ((event.currentTarget.scrollHeight) * 0.80) && getData("avoidcontinuouscalls").scroll) {

                    setData("avoidcontinuouscalls", {
                        scroll: false,
                        search: true
                    });

                    const PREVIOUSRESPONSE = getData("previouscallresponse").responseBody;

                    const FOLDER = getData("selectedfolder");

                    let folder_type = null;

                    if (FOLDER.category) {
                        folder_type = FOLDER.category;
                    } else if (FOLDER.type) {
                        folder_type = FOLDER.type;
                    } else {
                        folder_type = FOLDER.Search.search;
                    }
                    const REQUEST_OFFSET = getData("requestoffsets");
                    const PREV_OFFSET = REQUEST_OFFSET[folder_type];
                    const OFFSET = PREV_OFFSET + FILE_REQ_LMT;

                    if (PREVIOUSRESPONSE.hasOwnProperty("total_count") && PREVIOUSRESPONSE.total_count > OFFSET) {
                        getrequest(FOLDER.category, FOLDER.type, FOLDER.Search, OFFSET);
                    }
                    if (folder_type === "recent" && PREVIOUSRESPONSE.documents.length === FILE_REQ_LMT) {
                        getrequest(FOLDER.category, FOLDER.type, FOLDER.search, OFFSET);
                    }

                    REQUEST_OFFSET[folder_type] = OFFSET;
                    setData("requestoffsets", REQUEST_OFFSET);
                }
            });
        },
        eventforassociatewithUrl: (event) => {
            const KEY = event.which;
            if (event.type === "paste") {
                document.getElementById("js-associatewithUrl").value = "";
                const CLIPBD_DATA = event.clipboardData || event.originalEvent.clipboardData || window.clipboardData;
                const QUERY = CLIPBD_DATA.getData("text").trim();
                document.getElementById("js-associatewithUrl").value = '';
                if (QUERY.length > 0) {
                    setData("issearch", true);
                    setData("searchkeyentered", true);
                    const DOCUMENT_ID = Agile.Common.getDocID(QUERY);
                    if (DOCUMENT_ID) {
                        getFiles({
                            url: "/writer/api/v1/documents/" + DOCUMENT_ID,
                            method: "get"
                        }).then((response) => {
                            if (response.responseCode === 200) {
                                attachbtnevent(0);
                                setData("selectedCount", 0);
                                insertintoTemplate(response);
                            } else {
                                searchEmpty("No documents available", "The document you're searching for is either deleted or you don't have access to it.");
                            }
                        });
                    } else {
                        searchEmpty("No matching documents", "Please paste a valid URL");
                    }
                }
            } else if (event.type === "keyup" && getData("searchkeyentered") && KEY != 17 && KEY != 86 && KEY != 224) {
                document.getElementById("js-associatewithUrl").value = "";
                homePage();
            } else if (!getData("searchkeyentered")) {
                document.getElementById("js-associatewithUrl").value = "";
            }
        },
        eventforBody: (event) => {
            if (!event.target.classList.contains("js-drop_down")) {
                $("#js-dropdown-list").addClass("hide");
            }
        }
    };

    const bindEvents = () => {
        $(".js-writer-container").on("click", ".js-wr__AttachFiles", events.eventforAssociatebtn)
            .on("click", ".js__cancel", Agile.Common.closeModel)
            .on("click", ".js-drop_down", events.eventforDropdown)
            .on("click", ".js-dropdown-option", events.eventForSelection)
            .on("click", ".js-wr__attachUrlOptLnk", events.evetforAssociateUrl)
            .on("click", ".js__shrnkExpndSrchIco", events.eventforVisibleSearch)
            .on("click", ".js-btn—cancel", Agile.Common.closeModel)
            .on("click", ".js-wr-clear", events.eventforVisibleSearch)
            .on("keydown", "#js-searchInput", events.eventforSearch)
            .on("keyup", "#js-associatewithUrl", events.eventforassociatewithUrl)
            .on("paste", "#js-associatewithUrl", events.eventforassociatewithUrl);

        $("body").on("click", events.eventforBody);
        events.scrollDown();
    };

    const initValues = (search) => {
        setData("searchkeyentered", false);
        setData("issearch", search);
        setData('requestoffsets', {
            "recent": 0,
            "true": 0,
            "all": 0,
            "shared_to_me": 0,
            "favourite": 0
        });
    };

    const init = () => {
        setTemplates();
        initValues(false);
        checkboxevent();
        getAssociated_Document_Details();
        bindEvents();
        getwriterDocs("My Documents");

    };

    Object.defineProperties(this, {
        writerAssociate: {
            value: () => {
                init();
            }
        }
    });
});